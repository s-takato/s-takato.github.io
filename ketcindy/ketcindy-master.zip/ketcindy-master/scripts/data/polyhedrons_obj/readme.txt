Put data files in obj format into this folder.
For example, dowload data from
  http://mitani.cs.tsukuba.ac.jp/polyhedron/index.html
