Spacekcの使い方　　　　20190101 入谷昭

Spacekc は、KeTCindyの3Dモードをベースに，面の色塗りなど，KeTCindyにはないコマンドを追加したものです。

作成例は以下のサイトを見て下さい。
   https://sites.google.com/site/ketcindy/home/cindy3d2
