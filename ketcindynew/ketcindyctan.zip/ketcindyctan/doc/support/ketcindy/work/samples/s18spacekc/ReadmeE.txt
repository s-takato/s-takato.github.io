How to use Spacekc          20190101 Akira Iritani

Spacekc is a plugin  to KeTCindy for 3D rendering/drawing.

See the following website for examples : 
   https://sites.google.com/site/ketcindy/home/cindy3d2
